/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ims.dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 *
 * @author HMD
 */
public class EmloyeeDAL {

    Connection con;

    public EmloyeeDAL() throws ClassNotFoundException {
        try {
            String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
            String DB_URL = "jdbc:mysql://localhost:3306/baithi";
            String USER = "root";
            String PASS = "";
            Class.forName(JDBC_DRIVER);
            con = DriverManager.getConnection(DB_URL,USER,PASS);
        } catch (SQLException ex) {
            Logger.getLogger(EmloyeeDAL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public ResultSet getData(String stringSQL) {
        ResultSet rs = null;
        Statement state;
        try {
            state = con.createStatement();
            rs = state.executeQuery(stringSQL);
        } catch (SQLException ex) {
            Logger.getLogger(EmloyeeDAL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }
    
    //Viết hàm insert dữ liệu
    public int EMPLOYEE_Insert (String[] stringSQL){
        int row = 0;
        String insert = "Insert into main(Manv,Honv,Tennv,Sotk,Ngaysinh,Msthue,Tamtru,Dienthoai,Didong,Email,"
                + "CMND,Ngaycap,NgaygianhapDTN,ChucvuDTN,NoisinhhoatDTN,NgaygianhapDCS,ChucvuDCS,NooisinhhoatDCS,\n" +
                    "Ngaynhapngu,Ngayxuatngu,NoisinhhoatQD,Ghichu,Quan,Quoctich,TThonnhan,Vanhoa,"
                + "Hocvan,Noicap,Nguyenquan,Dantoc,Tongiao,Hokhau,Gioitinh,Thuongtru)) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement stament;
        try {
            stament = con.prepareCall(insert);          
            stament.setString(1,stringSQL[0]);
            stament.setString(2,stringSQL[1]);
            stament.setString(3,stringSQL[2]);
            stament.setString(4,stringSQL[3]);
            stament.setString(5,stringSQL[4]);
            stament.setString(6,stringSQL[5]);
            stament.setString(7,stringSQL[6]);
            stament.setString(8,stringSQL[7]);
            stament.setString(9,stringSQL[8]);
            stament.setString(10,stringSQL[9]);
            stament.setString(11,stringSQL[10]);
            stament.setString(12,stringSQL[11]);
            stament.setString(13,stringSQL[12]);
            stament.setString(14,stringSQL[13]);
            stament.setString(15,stringSQL[14]);
            stament.setString(16,stringSQL[15]);
            stament.setString(17,stringSQL[16]);
            stament.setString(18,stringSQL[17]);
            stament.setString(19,stringSQL[18]);
            stament.setString(20,stringSQL[19]);
            stament.setString(21,stringSQL[20]);
            stament.setString(22,stringSQL[21]);
            stament.setString(23,stringSQL[22]);
            stament.setString(24,stringSQL[23]);
            stament.setString(25,stringSQL[24]);
            stament.setString(26,stringSQL[25]);
            stament.setString(27,stringSQL[26]);
            stament.setString(28,stringSQL[27]);
            stament.setString(29,stringSQL[28]);
            stament.setString(30,stringSQL[29]);
            stament.setString(31,stringSQL[30]);
            stament.setString(32,stringSQL[31]);
            stament.setString(33,stringSQL[32]);
            stament.setString(34,stringSQL[33]);
            stament.setString(35,stringSQL[34]);
            row = stament.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(EmloyeeDAL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return row;
    }

}

